# Clear Carved Pumpkins

This is a minimal and stand-alone resource pack that removes the carved pumpkin overlay from first person.

It was constructed by following the instructions in this tutorial:
[How To Make CUSTOM HATS in Minecraft! Pt.1 - YouTube](https://www.youtube.com/watch?v=YBZbQGNxf18)
  
    
## License

This resourcepack, and its respecitve contents--including model assets and textures--are licensed by me
under [GPLv3](https://www.gnu.org/licenses/gpl-3.0.en.html). If you require a more permissive
license, I recommend making your own pack and assets using the source material, templates, programs and
tutorials linked above.

